"""Reliability metrics derived purely from the audit events (single source of truth)."""
from __future__ import annotations


def compute(events: list[dict]) -> dict:
    by = lambda name: [e for e in events if e["event"] == name]
    finished = (by("run_finished") or [{}])[-1]
    state_changes = by("state_change")
    done = {e["node"]: e["ts"] for e in state_changes if e["to_state"] == "DONE"}
    total_nodes = len(finished.get("states", {})) or len({e["node"] for e in state_changes})
    attempt_failed = by("attempt_failed")
    exhausted = [e for e in by("node_failed") if "retries exhausted" in e["reason"]]

    recoveries = []                      # MTTR: first failure -> node eventually DONE
    for node, ts_done in done.items():
        fails = [e["ts"] for e in attempt_failed if e["node"] == node]
        if fails:
            recoveries.append(ts_done - min(fails))

    return {
        "run_status": finished.get("status"),
        "run_success": finished.get("status") == "COMPLETED",
        "node_success_rate": round(len(done) / total_nodes, 3) if total_nodes else None,
        "end_to_end_latency_s": finished.get("latency_s"),
        "failed_attempts": len(attempt_failed),
        "retries": len(attempt_failed) - len(exhausted),
        "rollbacks": len(by("rollback")),
        "replans": len(by("replan")),
        "approvals_requested": len(by("approval")),
        "approvals_denied": len([e for e in by("approval") if not e["approved"]]),
        "policy_gate_failures": len([e for e in by("exit_gates") if e["failures"]]),
        "mttr_s": round(sum(recoveries) / len(recoveries), 4) if recoveries else None,
        "halt_reason": finished.get("halt_reason"),
    }
