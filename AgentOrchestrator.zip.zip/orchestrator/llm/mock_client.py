"""Deterministic offline LLM for demos and tests (no API key, no cost).

Two knobs make failure paths demonstrable:
  * fail_times: {"developer": 2}  -> first 2 calls for that role raise LLMError
  * scripted:   {"developer": [bad_code, good_code]} -> responses served in order
                (last one repeats), e.g. first answer violates policy.
"""
from __future__ import annotations

import threading
from collections import defaultdict

from .base import LLMError

REQUIREMENTS = """{
  "goal": "slugify(text) converts arbitrary text to a URL-safe slug",
  "functional": ["lowercase", "replace runs of non-alphanumerics with '-'", "strip leading/trailing '-'", "transliterate accents to ASCII", "optional max_length truncation"],
  "ambiguities": ["empty input -> return empty string (assumed)", "non-str input -> TypeError (assumed)"],
  "acceptance": ["slugify('Hello, World!') == 'hello-world'", "slugify('Crème Brûlée') == 'creme-brulee'"]
}"""

DESIGN = """Pure function slugify(text: str, max_length: int = 80) -> str in slugify.py.
Pipeline: validate type -> NFKD normalize + ASCII fold -> lowercase -> regex collapse -> strip '-' -> truncate (no trailing '-').
No I/O, no global state, no dependencies (stdlib only). Errors: TypeError (non-str), ValueError (max_length < 1)."""

GOOD_CODE = '''import re
import unicodedata


def slugify(text: str, max_length: int = 80) -> str:
    """Convert text to a URL-safe slug."""
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    if max_length < 1:
        raise ValueError("max_length must be >= 1")
    ascii_text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    slug = re.sub(r"[^a-z0-9]+", "-", ascii_text.lower()).strip("-")
    return slug[:max_length].rstrip("-")
'''

BAD_CODE_SECRET = GOOD_CODE + '\nAPI_KEY = "sk-live-1234567890abcdefgh"\n'

TESTS = '''def test_basic():
    assert slugify("Hello, World!") == "hello-world"

def test_accents():
    assert slugify("Crème Brûlée") == "creme-brulee"

def test_empty_and_symbols():
    assert slugify("") == ""
    assert slugify("!!!") == ""

def test_truncate_no_trailing_dash():
    assert slugify("hello world", max_length=6) == "hello"

def test_type_and_value_errors():
    for bad, kw, exc in [(None, {}, TypeError), ("a", {"max_length": 0}, ValueError)]:
        try:
            slugify(bad, **kw)
        except exc:
            continue
        raise AssertionError("expected " + exc.__name__)
'''

DOCS = "# slugify\n\n`slugify(text, max_length=80)` returns a lowercase, ASCII, hyphen-separated slug.\n\n| Input | Output |\n|---|---|\n| `Hello, World!` | `hello-world` |\n| `Crème Brûlée` | `creme-brulee` |\n\nRaises `TypeError` for non-str input and `ValueError` if `max_length < 1`.\n"

DEFAULTS = {
    "requirements": REQUIREMENTS,
    "architect": DESIGN,
    "developer": GOOD_CODE,
    "tester": TESTS,
    "doc_writer": DOCS,
    "reviewer": "APPROVE: code, tests and docs are consistent with the design.",
}


class MockLLM:
    def __init__(self, fail_times: dict[str, int] | None = None,
                 scripted: dict[str, list[str]] | None = None) -> None:
        self.fail_times = dict(fail_times or {})
        self.scripted = scripted or {}
        self.calls: dict[str, int] = defaultdict(int)
        self._lock = threading.Lock()

    def complete(self, role: str, prompt: str) -> str:
        with self._lock:
            self.calls[role] += 1
            n = self.calls[role]
        if n <= self.fail_times.get(role, 0):
            raise LLMError(f"injected failure for {role} (call {n})")
        if role in self.scripted:
            seq = self.scripted[role]
            return seq[min(n - 1 - self.fail_times.get(role, 0), len(seq) - 1)]
        return DEFAULTS[role]
