"""Security policy checks for generated Python code (AST + regex)."""
from __future__ import annotations

import ast
import re

SECRET_PATTERNS = [
    r"(?i)(api[_-]?key|secret|password|token)\s*=\s*['\"][^'\"]{8,}['\"]",
    r"sk-[A-Za-z0-9\-]{10,}",
    r"AKIA[0-9A-Z]{16}",
]
FORBIDDEN_CALLS = {"eval", "exec", "compile", "__import__"}
FORBIDDEN_ATTRS = {("os", "system"), ("subprocess", "Popen"), ("subprocess", "run")}


def check_security(code: str) -> list[str]:
    violations = [f"possible hardcoded secret (pattern {i})"
                  for i, p in enumerate(SECRET_PATTERNS) if re.search(p, code)]
    try:
        tree = ast.parse(code)
    except SyntaxError as exc:
        return violations + [f"syntax error: {exc.msg}"]
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            f = node.func
            if isinstance(f, ast.Name) and f.id in FORBIDDEN_CALLS:
                violations.append(f"forbidden call: {f.id}()")
            if isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name) \
                    and (f.value.id, f.attr) in FORBIDDEN_ATTRS:
                violations.append(f"forbidden call: {f.value.id}.{f.attr}()")
    return violations
