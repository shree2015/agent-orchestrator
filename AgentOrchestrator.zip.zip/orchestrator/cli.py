"""Usage:  python -m orchestrator.cli run slugify [--approve ask|auto|deny:<node>] [--fail developer:2] [--leak-secret]"""
from __future__ import annotations

import argparse

from .governance import approvals
from .llm.mock_client import BAD_CODE_SECRET, GOOD_CODE, MockLLM
from .runner import run_workflow
from .workflows import slugify


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="orchestrate")
    sub = p.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run")
    r.add_argument("workflow", choices=["slugify"])
    r.add_argument("--approve", default="ask", help="ask | auto | deny:<node_id>")
    r.add_argument("--fail", action="append", default=[], help="inject LLM failures, e.g. developer:2")
    r.add_argument("--leak-secret", action="store_true", help="developer's first answer contains a hardcoded secret")
    a = p.parse_args(argv)

    fail = {k: int(v) for k, v in (x.split(":") for x in a.fail)}
    scripted = {"developer": [BAD_CODE_SECRET, GOOD_CODE]} if a.leak_secret else None
    llm = MockLLM(fail_times=fail, scripted=scripted)
    approver = (approvals.cli_approver if a.approve == "ask" else approvals.auto_approver if a.approve == "auto"
                else approvals.deny_approver(*a.approve.split(":")[1:]))

    graph, agents = slugify.build(llm)
    res = run_workflow(graph, agents, approver)
    print(f"\nStatus: {res['status'].value} | run dir: {res['run_dir']}")
    print((res["run_dir"] / "report.md").read_text())
    return 0 if res["metrics"]["run_success"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
