"""Stateful DAG execution engine.

Execution model
---------------
* The engine repeatedly finds nodes whose dependencies are all DONE and runs
  that whole "wave" in parallel (thread pool). A node with several parents is
  only released once ALL parents are DONE -> natural synchronization point.
* Per node: entry gates -> agent (bounded retries) -> exit gates -> optional
  human approval -> commit output to shared context.
* Outputs are committed to the context ONLY after every check passes, so a
  failed node never pollutes downstream context (cheap, safe "rollback").
* Any unrecoverable failure, rejection, or exceeded budget triggers SAFE-STOP:
  no new nodes start, unstarted descendants are SKIPPED.
* invalidate() supports dynamic re-planning: marks a node and everything
  downstream STALE, drops their outputs, and the next run() redoes them.

TODO (next iterations, kept out of the skeleton on purpose):
  fallback agents, backoff, persistent state, richer rollback (artifact
  snapshots), lineage store, metrics module.
"""
from __future__ import annotations

import threading
import time
from concurrent.futures import ThreadPoolExecutor
from types import MappingProxyType
from typing import Any, Callable, Mapping

from .graph import Graph, Node
from .state import NodeState, RunStatus

Agent = Callable[[Mapping[str, Any]], Any]          # context -> output
Approver = Callable[[Node, Any], bool]              # (node, output) -> approved?
AuditSink = Callable[[dict], None]


class Engine:
    def __init__(
        self,
        graph: Graph,
        agents: dict[str, Agent],
        approver: Approver | None = None,
        audit: AuditSink | None = None,
        max_workers: int = 4,
        max_total_attempts: int = 50,   # safe-stop budget across the whole run
    ) -> None:
        graph.validate()
        missing = {n.agent for n in graph.nodes.values()} - set(agents)
        if missing:
            raise ValueError(f"no agent registered for: {sorted(missing)}")
        self.graph = graph
        self.agents = agents
        self.approver = approver or (lambda node, output: False)  # deny by default
        self._audit_sink = audit or (lambda event: None)
        self.max_workers = max_workers
        self.max_total_attempts = max_total_attempts

        self.state: dict[str, NodeState] = {n: NodeState.PENDING for n in graph.nodes}
        self.context: dict[str, Any] = {}      # node_id -> committed output
        self.attempts: dict[str, int] = {n: 0 for n in graph.nodes}
        self._total_attempts = 0
        self._lock = threading.Lock()
        self._halt = threading.Event()
        self.halt_reason: str | None = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def run(self) -> RunStatus:
        started = time.monotonic()
        self._audit("run_started", pending=self._ids(NodeState.PENDING))
        with ThreadPoolExecutor(max_workers=self.max_workers) as pool:
            while not self._halt.is_set():
                ready = self._ready_nodes()
                if not ready:
                    break
                self._audit("wave_started", nodes=[n.id for n in ready])
                futures = [pool.submit(self._execute_node, n) for n in ready]
                for f in futures:      # barrier: wait for the whole wave
                    f.result()

        status = self._final_status()
        if status is RunStatus.HALTED:
            self._skip_unstarted()
        self._audit(
            "run_finished",
            status=status.value,
            halt_reason=self.halt_reason,
            latency_s=round(time.monotonic() - started, 4),
            states={k: v.value for k, v in self.state.items()},
        )
        return status

    def invalidate(self, node_id: str, reason: str) -> set[str]:
        """Dynamic re-plan: an upstream output changed, redo it and its dependents."""
        affected = {node_id} | self.graph.downstream(node_id)
        for nid in affected:
            self.state[nid] = NodeState.PENDING
            self.context.pop(nid, None)
        self._halt.clear()
        self.halt_reason = None
        self._audit("replan", trigger=node_id, reason=reason, invalidated=sorted(affected))
        return affected

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------
    def _ready_nodes(self) -> list[Node]:
        return [
            n for nid, n in self.graph.nodes.items()
            if self.state[nid] is NodeState.PENDING
            and all(self.state[d] is NodeState.DONE for d in n.depends_on)
        ]

    def _execute_node(self, node: Node) -> None:
        if self._halt.is_set():
            return
        self._set(node.id, NodeState.RUNNING)
        ctx: Mapping[str, Any] = MappingProxyType(dict(self.context))  # read-only snapshot

        # 1. entry gates
        for gate in node.entry_gates:
            ok, why = gate(ctx)
            self._audit("entry_gate", node=node.id, passed=ok, reason=why)
            if not ok:
                return self._fail(node, f"entry gate failed: {why}")

        # 2. agent with bounded retries (exit gates are part of "success")
        output, last_error = None, ""
        for attempt in range(1, node.max_retries + 2):
            if not self._consume_budget(node):
                return
            self.attempts[node.id] += 1
            try:
                output = self.agents[node.agent](ctx)
                failed = [(g, g(ctx, output)) for g in node.exit_gates]
                bad = [why for _, (ok, why) in failed if not ok]
                self._audit("exit_gates", node=node.id, attempt=attempt, failures=bad)
                if not bad:
                    last_error = ""
                    break
                last_error = "; ".join(bad)
            except Exception as exc:  # agent crashed
                last_error = f"{type(exc).__name__}: {exc}"
            self._audit("attempt_failed", node=node.id, attempt=attempt, error=last_error)
        if last_error:
            return self._fail(node, f"retries exhausted: {last_error}")

        # 3. human approval for high-impact nodes
        if node.requires_approval:
            self._set(node.id, NodeState.AWAITING_APPROVAL)
            approved = self.approver(node, output)
            self._audit("approval", node=node.id, approved=approved)
            if not approved:
                self._set(node.id, NodeState.REJECTED)
                return self._safe_stop(f"{node.id} rejected by human")

        # 4. commit
        with self._lock:
            self.context[node.id] = output
        self._set(node.id, NodeState.DONE)

    def _consume_budget(self, node: Node) -> bool:
        with self._lock:
            self._total_attempts += 1
            if self._total_attempts > self.max_total_attempts:
                self._safe_stop("attempt budget exceeded")
                self.state[node.id] = NodeState.FAILED
                return False
        return True

    def _fail(self, node: Node, reason: str) -> None:
        self._set(node.id, NodeState.FAILED)
        self._audit("node_failed", node=node.id, reason=reason)
        self._safe_stop(f"{node.id}: {reason}")

    def _safe_stop(self, reason: str) -> None:
        if not self._halt.is_set():
            self.halt_reason = reason
            self._halt.set()
            self._audit("safe_stop", reason=reason)

    def _skip_unstarted(self) -> None:
        for nid, st in self.state.items():
            if st is NodeState.PENDING:
                self.state[nid] = NodeState.SKIPPED

    def _final_status(self) -> RunStatus:
        if self._halt.is_set():
            return RunStatus.HALTED
        if all(s is NodeState.DONE for s in self.state.values()):
            return RunStatus.COMPLETED
        return RunStatus.DEADLOCK

    def _set(self, node_id: str, new: NodeState) -> None:
        old = self.state[node_id]
        self.state[node_id] = new
        self._audit("state_change", node=node_id, from_state=old.value, to_state=new.value)

    def _ids(self, st: NodeState) -> list[str]:
        return sorted(n for n, s in self.state.items() if s is st)

    def _audit(self, event: str, **data: Any) -> None:
        self._audit_sink({"ts": time.time(), "event": event, **data})
