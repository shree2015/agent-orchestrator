"""Runs a workflow and persists audit log, metrics, artifacts and a markdown report."""
from __future__ import annotations

import json
import time
import uuid
from pathlib import Path

from .core.engine import Engine
from .observability import metrics as metrics_mod
from .observability.audit_log import AuditLog

EXT = {"implementation": "py", "tests": "py", "requirements": "json"}


def run_workflow(graph, agents, approver, run_root: str | Path = "runs", run_id: str | None = None) -> dict:
    run_id = run_id or f"{time.strftime('run-%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:6]}"
    run_dir = Path(run_root) / run_id
    audit = AuditLog(run_dir / "audit.jsonl")
    engine = Engine(graph, agents, approver=approver, audit=audit)
    status = engine.run()

    m = metrics_mod.compute(audit.events)
    (run_dir / "metrics.json").write_text(json.dumps(m, indent=2))
    art = run_dir / "artifacts"
    art.mkdir(exist_ok=True)
    for node_id, out in engine.context.items():
        (art / f"{node_id}.{EXT.get(node_id, 'md')}").write_text(out["content"])
    (run_dir / "report.md").write_text(render_report(run_id, engine, m, audit))
    return {"run_id": run_id, "run_dir": run_dir, "status": status, "metrics": m, "engine": engine, "audit": audit}


def render_report(run_id, engine, m, audit) -> str:
    rows = "\n".join(f"| {n} | {s.value} | {engine.attempts[n]} |" for n, s in engine.state.items())
    lineage = "\n".join(f"- **{n}** <- {', '.join(o['derived_from']) or '(requirement)'}"
                        for n, o in engine.context.items())
    mrows = "\n".join(f"| {k} | {v} |" for k, v in m.items())
    ok = AuditLog.verify(audit.path)
    return (f"# Run report: {run_id}\n\n**Status:** {m['run_status']}  \n"
            f"**Halt reason:** {m['halt_reason'] or '-'}  \n**Audit chain intact:** {ok}\n\n"
            f"## Nodes\n| Node | State | Attempts |\n|---|---|---|\n{rows}\n\n"
            f"## Decision lineage\n{lineage}\n\n## Reliability metrics\n| Metric | Value |\n|---|---|\n{mrows}\n")
