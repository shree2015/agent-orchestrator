import json

from orchestrator.core.state import NodeState, RunStatus
from orchestrator.governance import approvals, policy_engine
from orchestrator.llm.mock_client import BAD_CODE_SECRET, GOOD_CODE, MockLLM
from orchestrator.observability.audit_log import AuditLog
from orchestrator.runner import run_workflow
from orchestrator.workflows import slugify


def go(tmp_path, llm=None, approver=approvals.auto_approver):
    graph, agents = slugify.build(llm or MockLLM())
    return run_workflow(graph, agents, approver, run_root=tmp_path, run_id="t")


def test_happy_path_and_artifacts(tmp_path):
    r = go(tmp_path)
    assert r["status"] is RunStatus.COMPLETED
    assert (r["run_dir"] / "artifacts" / "implementation.py").exists()
    assert r["metrics"]["retries"] == 0 and r["metrics"]["node_success_rate"] == 1.0


def test_llm_failures_retry_then_recover(tmp_path):
    r = go(tmp_path, MockLLM(fail_times={"developer": 2}))
    assert r["status"] is RunStatus.COMPLETED
    assert r["metrics"]["retries"] == 2 and r["metrics"]["mttr_s"] is not None


def test_too_many_failures_safe_stop(tmp_path):
    r = go(tmp_path, MockLLM(fail_times={"developer": 5}))
    assert r["status"] is RunStatus.HALTED
    assert r["engine"].state["tests"] is NodeState.SKIPPED
    assert r["engine"].attempts["implementation"] == 3


def test_secret_blocked_by_policy_then_clean_retry(tmp_path):
    r = go(tmp_path, MockLLM(scripted={"developer": [BAD_CODE_SECRET, GOOD_CODE]}))
    assert r["status"] is RunStatus.COMPLETED
    assert r["metrics"]["policy_gate_failures"] == 1
    assert "API_KEY" not in (r["run_dir"] / "artifacts" / "implementation.py").read_text()


def test_persistent_policy_violation_halts_without_committing(tmp_path):
    r = go(tmp_path, MockLLM(scripted={"developer": [BAD_CODE_SECRET]}))
    assert r["status"] is RunStatus.HALTED
    assert "implementation" not in r["engine"].context


def test_bad_generated_tests_are_caught_by_sandbox_gate(tmp_path):
    wrong = "def test_wrong():\n    assert slugify('A B') == 'a_b'\n"
    r = go(tmp_path, MockLLM(scripted={"tester": [wrong]}))
    assert r["status"] is RunStatus.HALTED and "tests failed" in r["metrics"]["halt_reason"]


def test_human_rejection_at_design(tmp_path):
    r = go(tmp_path, approver=approvals.deny_approver("design"))
    assert r["status"] is RunStatus.HALTED
    assert r["engine"].state["design"] is NodeState.REJECTED
    assert r["engine"].state["implementation"] is NodeState.SKIPPED


def test_release_requires_human_approval(tmp_path):
    r = go(tmp_path, approver=approvals.deny_approver("release"))
    assert r["engine"].state["release"] is NodeState.REJECTED
    assert r["metrics"]["approvals_denied"] == 1


def test_audit_chain_verifies_and_detects_tampering(tmp_path):
    r = go(tmp_path)
    path = r["run_dir"] / "audit.jsonl"
    assert AuditLog.verify(path)
    lines = path.read_text().splitlines()
    rec = json.loads(lines[3]); rec["event"] = "tampered"; lines[3] = json.dumps(rec)
    path.write_text("\n".join(lines) + "\n")
    assert not AuditLog.verify(path)


def test_lineage_recorded(tmp_path):
    r = go(tmp_path)
    assert r["engine"].context["implementation"]["derived_from"] == ["requirements", "design"]


def test_policy_engine_rules():
    assert policy_engine.check_security(GOOD_CODE) == []
    assert policy_engine.check_security("eval('1')")
    assert policy_engine.check_security("import os\nos.system('ls')")
    assert policy_engine.check_security(BAD_CODE_SECRET)
