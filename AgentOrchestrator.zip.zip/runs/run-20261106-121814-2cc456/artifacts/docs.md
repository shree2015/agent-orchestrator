# slugify

`slugify(text, max_length=80)` returns a lowercase, ASCII, hyphen-separated slug.

| Input | Output |
|---|---|
| `Hello, World!` | `hello-world` |
| `Cr�me Br�l�e` | `creme-brulee` |

Raises `TypeError` for non-str input and `ValueError` if `max_length < 1`.
