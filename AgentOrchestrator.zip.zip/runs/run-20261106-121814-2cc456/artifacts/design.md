Pure function slugify(text: str, max_length: int = 80) -> str in slugify.py.
Pipeline: validate type -> NFKD normalize + ASCII fold -> lowercase -> regex collapse -> strip '-' -> truncate (no trailing '-').
No I/O, no global state, no dependencies (stdlib only). Errors: TypeError (non-str), ValueError (max_length < 1).