# Run report: run-20261106-035533-d79ab7

**Status:** HALTED  
**Halt reason:** release rejected by human  
**Audit chain intact:** True

## Nodes
| Node | State | Attempts |
|---|---|---|
| requirements | DONE | 1 |
| design | DONE | 1 |
| implementation | DONE | 1 |
| tests | DONE | 1 |
| docs | DONE | 1 |
| review | DONE | 1 |
| release | REJECTED | 1 |

## Decision lineage
- **requirements** <- (requirement)
- **design** <- requirements
- **implementation** <- requirements, design
- **docs** <- design, implementation
- **tests** <- requirements, implementation
- **review** <- implementation, tests, docs

## Reliability metrics
| Metric | Value |
|---|---|
| run_status | HALTED |
| run_success | False |
| node_success_rate | 0.857 |
| end_to_end_latency_s | 0.0305 |
| failed_attempts | 0 |
| retries | 0 |
| rollbacks | 0 |
| replans | 0 |
| approvals_requested | 2 |
| approvals_denied | 1 |
| policy_gate_failures | 0 |
| mttr_s | None |
| halt_reason | release rejected by human |
