import re
import unicodedata


def slugify(text: str, max_length: int = 80) -> str:
    """Convert text to a URL-safe slug."""
    if not isinstance(text, str):
        raise TypeError("text must be a str")
    if max_length < 1:
        raise ValueError("max_length must be >= 1")
    ascii_text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    slug = re.sub(r"[^a-z0-9]+", "-", ascii_text.lower()).strip("-")
    return slug[:max_length].rstrip("-")
