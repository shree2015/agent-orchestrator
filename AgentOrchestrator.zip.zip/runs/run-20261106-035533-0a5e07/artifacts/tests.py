def test_basic():
    assert slugify("Hello, World!") == "hello-world"

def test_accents():
    assert slugify("Crème Brûlée") == "creme-brulee"

def test_empty_and_symbols():
    assert slugify("") == ""
    assert slugify("!!!") == ""

def test_truncate_no_trailing_dash():
    assert slugify("hello world", max_length=6) == "hello"

def test_type_and_value_errors():
    for bad, kw, exc in [(None, {}, TypeError), ("a", {"max_length": 0}, ValueError)]:
        try:
            slugify(bad, **kw)
        except exc:
            continue
        raise AssertionError("expected " + exc.__name__)
