# Run report: run-20261106-122059-3802da

**Status:** HALTED  
**Halt reason:** design rejected by human  
**Audit chain intact:** True

## Nodes
| Node | State | Attempts |
|---|---|---|
| requirements | DONE | 1 |
| design | REJECTED | 1 |
| implementation | SKIPPED | 0 |
| tests | SKIPPED | 0 |
| docs | SKIPPED | 0 |
| review | SKIPPED | 0 |
| release | SKIPPED | 0 |

## Decision lineage
- **requirements** <- (requirement)

## Reliability metrics
| Metric | Value |
|---|---|
| run_status | HALTED |
| run_success | False |
| node_success_rate | 0.143 |
| end_to_end_latency_s | 0.015 |
| failed_attempts | 0 |
| retries | 0 |
| rollbacks | 0 |
| replans | 0 |
| approvals_requested | 1 |
| approvals_denied | 1 |
| policy_gate_failures | 0 |
| mttr_s | None |
| halt_reason | design rejected by human |
