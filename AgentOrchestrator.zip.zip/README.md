# Agentic SDLC Orchestrator (work in progress)

## Quickstart (Python 3.10+, stdlib only for the core)
    python -m orchestrator.cli run slugify --approve auto
    python -m orchestrator.cli run slugify --approve auto --fail developer:2     # LLM failures -> retries
    python -m orchestrator.cli run slugify --approve auto --leak-secret          # policy gate blocks a leaked secret
    python -m orchestrator.cli run slugify --approve deny:design                 # human rejects -> safe-stop
    python -m orchestrator.cli run slugify                                       # interactive approvals
Each run writes `runs/<id>/{audit.jsonl, metrics.json, report.md, artifacts/}`.

## Tests
    pip install pytest && pytest

## Simple graph version (start here to understand the design)
    python -m simple_graph.demo happy
    python -m simple_graph.demo fix_loop          # tests fail -> loops back to developer -> passes
    python -m simple_graph.demo always_bad        # retry loop is bounded -> safe stop
    python -m simple_graph.demo reject_once       # human rejects design -> back to architect
    python -m simple_graph.demo happy --engine langgraph   # same graph run by LangGraph
    python -m simple_graph.demo happy --ask       # YOU approve the design
